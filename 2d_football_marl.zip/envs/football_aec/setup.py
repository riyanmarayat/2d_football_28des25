def create_players(agent_names):
    from agents import BasicPlayer
    players = []
    for name in agent_names:
        team = "left" if int(name.split("_")[1]) < 11 else "right"
        players.append(BasicPlayer(name=name, side=team))
    return players

def create_ball():
    from objects import Ball
    return Ball()

def create_field():
    from objects import Field
    return Field()

def create_recorder():
    from utils import Recorder
    return Recorder()