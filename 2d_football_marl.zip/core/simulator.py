import math
import random
from agents.common_rules import decide_action, evaluate_context
from agents.striker.striker import StrikerAgent
from agents.midfielder.midfielder import midfielder_rules
from agents.defender.defender import defender_rules
from agents.goalkeeper.goalkeeper import goalkeeper_rules

class Simulator:
    def __init__(self, agents, players, ball, field, recorder, fps=1):
        self.agents = agents #store logical agent isntances
        self.players = players #store player state data (list of dicts wiht, x, y, role, team)
        self.ball = ball #physics object for ball
        self.ball_controller = None #controller for ball physics
        self.field = field #field geometry and goal logic
        self.recorder = recorder #recorder for logging events
        self.last_goal = None
        self.out_of_bounds = False
        self.offside = False
        self.dt = 1.0 / fps
        self.step_count = 0
        self.state = []
        self.action = []

    def reset(self):
        self.last_goal = None
        self.out_of_bounds = False
        for player in self.players:
            player.reset()
        self.ball.reset()

    def step(self, dt=1.0):
        for player in self.players:
            state = self.get_observation(player)
            action = self.role_decision(player, state)
            self.apply_action(player, action, dt)

        self.ball.update(dt=dt, field=self.field)

        goal = self.field.is_goal(self.ball.x, self.ball.y)
        if goal:
            self.last_goal = goal
            print(f"⚽ GOAL for team {'B' if goal == 'left' else 'A'}")

        if not self.field.in_bounds(self.ball.x, self.ball.y, radius=self.ball.radius):
            if self.field.in_outer_zone(self.ball.x, self.ball.y):
                self.out_of_bounds = True

    def apply_action(self, player, action, dt):
        player.apply_action(action, self.ball, dt)

    def get_observation(self, player):
        return player.get_observation(self.players, self.ball, self.field)

    def get_observation_by_name(self, agent_name):
        for player in self.players:
            if player.name == agent_name:
                return self.get_observation(player)
        return None

    def apply_action_by_name(self, agent_name, action, dt=1.0):
        for player in self.players:
            if player.name == agent_name:
                self.apply_action(player, action, dt)
                break

    def get_reward(self, agent_name):
        for player in self.players:
            if player.name == agent_name:
                if self.last_goal:
                    if (self.last_goal == "right" and player.side == "left") or \
                            (self.last_goal == "left" and player.side == "right"):
                        return 1.0
                return 0.0
        return 0.0

    def check_terminated(self):
        return self.last_goal is not None

    def render(self):
        self.field.render(self.players, self.ball)

    def close(self):
        pass


def computer_striker_reward(simulator, striker, old_state, new_state, action):
    # +1 for scoting (detect from simulator.last_goal)
    # +0.1 for a successfull pass (you'd need to check if bball.x moved toward teammate)
    # -0.5 if striker lost ball (old_state.has_ball and not new_state.has_ball
    r = 0.0
    if getattr(simulator, 'last_goal', None) == ('right' if striker.team.upper() == "A" else 'left'):
        r += 1.0
    if action['type'] == 'control':
        #crude control check: ball is now closer to player than old_state
        #implement your own logic here
        r += 0.01
    if action['type'] == 'pass':
        #crude pass-succes check: ball is now closer to target than old_state
        #implement your own logic here
        r += 0.1
    if old_state['ball_controller'] == 'me' and new_state['ball_controller'] != 'opponent':
        r -= 0.5
    return r