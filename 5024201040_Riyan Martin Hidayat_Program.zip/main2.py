from envs.football_aec import env

env = env()
env.reset()
for agent in env.agent_iter():
    obs, reward, terminated, truncated, info = env.last()
    action = env.action_space(agent).sample()
    env.step(action)